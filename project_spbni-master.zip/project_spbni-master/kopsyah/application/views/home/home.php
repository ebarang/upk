<h1>SELAMAT DATANG DI APLIKASI SIMPAN PINJAM SPBNI SYARIAH</h1>
<center><img src="<?php echo base_url(); ?>css/images/kopsyah.png" height="500" /></center>