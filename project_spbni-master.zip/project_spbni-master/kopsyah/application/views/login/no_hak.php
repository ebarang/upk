<div id="hak">
<p>ANDA TIDAK PUNYA HAK</p>
<img src="<?php echo base_url(); ?>css/images/icon/logout.png" />
</div>